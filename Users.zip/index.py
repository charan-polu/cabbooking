from tkinter import *
from tkinter import ttk
import random
import time
import datetime
from tkinter import messagebox as ms
import sqlite3


Item4 = 0

with sqlite3.connect('Users.db') as db:
    c = db.cursor()

c.execute('CREATE TABLE IF NOT EXISTS user (username TEXT NOT NULL ,password TEXT NOT NULL)')
db.commit()
db.close()

#main Class
class user:
    def __init__(self,master):
        self.master = master
        self.username = StringVar()
        self.password = StringVar()
        self.n_username = StringVar()
        self.n_password = StringVar()
        self.widgets()

    
    def login(self):
        with sqlite3.connect('Users.db') as db:
            c = db.cursor()
        find_user = ('SELECT * FROM user WHERE username = ? and password = ?')
        c.execute(find_user,[(self.username.get()),(self.password.get())])
        result = c.fetchall()
        if result:
            self.logf.pack_forget()
            self.head['text'] = "* WELCOME " + (self.username.get()).upper()+" TO BOOKING PAGE *"
            self.head.configure(fg="black")
            self.head.pack(fill=X)
            application = travel(root)
            
        else:
            ms.showerror('Oops!','Username Not Found.')
            
    def new_user(self):
        with sqlite3.connect('Users.db') as db:
            c = db.cursor()
        find_user = ('SELECT * FROM user WHERE username = ?')
        c.execute(find_user,[(self.username.get())])        
        if c.fetchall():
            ms.showerror('Error!','Username Already Taken!, Try again!!! if encountering the problem again login with username:abhi and password:123')
        else:
            ms.showinfo('Success!','Account Created!')
            self.log()
        insert = 'INSERT INTO user(username,password) VALUES(?,?)'
        c.execute(insert,[(self.n_username.get()),(self.n_password.get())])
        db.commit()
    def log(self):
        self.username.set('')
        self.password.set('')
        self.crf.pack_forget()
        self.head['text'] = 'LOGIN!'
        self.logf.pack()
    def cr(self):
        self.n_username.set('')
        self.n_password.set('')
        self.logf.pack_forget()
        self.head['text'] = 'NEW USER!'
        self.crf.pack()
    def widgets(self):
        self.head = Label(self.master,text = 'LOGIN',font = ('Times',35),pady = 10,)
        self.head.pack()
        self.logf = Frame(self.master,padx =10,pady = 10)
        Label(self.logf,text = 'USERNAME: ',font = ('TIMES',20),pady=5,padx=5).grid(sticky = W)
        Entry(self.logf,textvariable = self.username,bd = 5,font = ('',15)).grid(row=0,column=1)
        Label(self.logf,text = 'PASSWORD: ',font = ('TIMES',20),pady=5,padx=5).grid(sticky = W)
        Entry(self.logf,textvariable = self.password,bd = 5,font = ('',15),show = '*').grid(row=1,column=1)
        Button(self.logf,text = ' SUBMIT ',bd = 3 ,font = ('TIMES',15),padx=5,pady=5,command=self.login).grid()
        Button(self.logf,text = ' REGISTER ',bd = 3 ,font = ('TIMES',15),padx=5,pady=5,command=self.cr).grid(row=2,column=1)
        self.logf.pack()
        
        self.crf = Frame(self.master,padx =10,pady = 10)
        Label(self.crf,text = 'USERNAME: ',font = ('TIMES',20),pady=5,padx=5).grid(sticky = W)
        Entry(self.crf,textvariable = self.n_username,bd = 5,font = ('TIMES',15)).grid(row=0,column=1)
        Label(self.crf,text = 'PASSWORD: ',font = ('TIMES',20),pady=5,padx=5).grid(sticky = W)
        Entry(self.crf,textvariable = self.n_password,bd = 5,font = ('TIMES',15),show = '*').grid(row=1,column=1)
        Button(self.crf,text = 'CREATE ACCOUNT',bd = 3 ,font = ('TIMES',15),padx=5,pady=5,command=self.new_user).grid()
        Button(self.crf,text = 'GO TO LOGIN',bd = 3 ,font = ('TIMES',15),padx=5,pady=5,command=self.log).grid(row=2,column=1)

class travel:

    def __init__(self,root):
        self.root = root
        self.root.title("Cab Booking System In LPU")
        self.root.geometry(geometry) 
        self.root.configure(background='black')

        DateofOrder=StringVar()
        DateofOrder.set(time.strftime(" %d / %m / %Y "))
        Receipt_Ref=StringVar()
        PaidTax=StringVar()
        SubTotal=StringVar()
        TotalCost=StringVar()

        var1=IntVar()
        var2=IntVar()
        var3=IntVar()
        var4=IntVar()
        journeyType=IntVar()
        carType=IntVar()
        
        varl1=StringVar()
        varl2=StringVar()
        varl3=StringVar()
        reset_counter=0


        Name=StringVar()
        UID=StringVar()
        Address=StringVar()
        Mobile=StringVar()
        Email=StringVar()

        TaxiTax=StringVar()
        Km=StringVar()
        Luggage=StringVar()
        Receipt=StringVar()


        EAUTO=StringVar()
        PrimeSedan=StringVar()
        PremiumSedan=StringVar()


        TaxiTax.set("0")
        Km.set("0")
        Luggage.set("0")


        EAUTO.set("0")
        PrimeSedan.set("0")
        PremiumSedan.set("0")        

        def iExit():
            iExit= ms.askyesno("Prompt!","Do you want to exit?")
            if iExit > 0:
                root.destroy()
                return

        def Reset():
            TaxiTax.set("0")
            Km.set("0")
            Travel_Ins.set("0")
            Luggage.set("0")

            EAUTO.set("0")
            PrimeSedan.set("0")
            PremiumSedan.set("0")

            Name.set("")
            UID.set("")
            Address.set("")
            Mobile.set("")
            Email.set("")

            PaidTax.set("")
            SubTotal.set("")
            TotalCost.set("")
            self.txtReceipt1.delete("1.0",END)
            self.txtReceipt2.delete("1.0",END)
            
            var1.set(0)
            var2.set(0)
            var3.set(0)
            var4.set(0)
            journeyType.set(0)
            carType.set(0)
            varl1.set("0")
            varl2.set("0")
            varl3.set("0")

            self.cboPickup.current(0)
            self.cboDrop.current(0)
            self.cboPooling.current(0)

            self.txtTaxiTax.configure(state=DISABLED)
            self.txtKm.configure(state=DISABLED)
            self.txtLuggage.configure(state=DISABLED)
        
            self.txtEAUTO.configure(state=DISABLED)
            self.txtPrimeSedan.configure(state=DISABLED)
            self.txtPremiumSedan.configure(state=DISABLED)
            self.reset_counter=1

        def Receiptt():
            if reset_counter is 0 and Name.get()!="" and Name.get()!="" and Address.get()!=""  and Mobile.get()!="" and  Email.get()!="":
                self.txtReceipt1.delete("1.0",END)
                self.txtReceipt2.delete("1.0",END)
                x=random.randint(10853,500831)
                randomRef = str(x)
                Receipt_Ref.set(randomRef)

                self.txtReceipt1.insert(END,"Receipt Ref:\n")
                self.txtReceipt2.insert(END, Receipt_Ref.get() + "\n")
                self.txtReceipt1.insert(END,'Date:\n')
                self.txtReceipt2.insert(END, DateofOrder.get() + "\n")
                self.txtReceipt1.insert(END,'Taxi No:\n')
                self.txtReceipt2.insert(END, 'TR ' + Receipt_Ref.get() + " BW\n")
                self.txtReceipt1.insert(END,'Name:\n')
                self.txtReceipt2.insert(END, Name.get() + "\n")
                self.txtReceipt1.insert(END,'UID:\n')
                self.txtReceipt2.insert(END, UID.get() + "\n")
                self.txtReceipt1.insert(END,'Address:\n')
                self.txtReceipt2.insert(END, Address.get() + "\n")
                self.txtReceipt1.insert(END,'Mobile:\n')
                self.txtReceipt2.insert(END, Mobile.get() + "\n")
                self.txtReceipt1.insert(END,'Email:\n')
                self.txtReceipt2.insert(END, Email.get() + "\n")
                self.txtReceipt1.insert(END,'From:\n')
                self.txtReceipt2.insert(END, varl1.get() + "\n")
                self.txtReceipt1.insert(END,'To:\n')
                self.txtReceipt2.insert(END, varl2.get() + "\n")
                self.txtReceipt1.insert(END,'Pooling:\n')
                self.txtReceipt2.insert(END, varl3.get() + "\n")
                self.txtReceipt1.insert(END,'EAUTO:\n')
                self.txtReceipt2.insert(END, EAUTO.get() + "\n")
                self.txtReceipt1.insert(END,'Prime Sedan:\n')
                self.txtReceipt2.insert(END, PrimeSedan.get() + "\n")
                self.txtReceipt1.insert(END,'Premium Sedan:\n')
                self.txtReceipt2.insert(END, PremiumSedan.get() + "\n")
                self.txtReceipt1.insert(END,'Paid:\n')
                self.txtReceipt2.insert(END, PaidTax.get() + "\n")
                self.txtReceipt1.insert(END,'SubTotal:\n')
                self.txtReceipt2.insert(END, str(SubTotal.get()) + "\n")
                self.txtReceipt1.insert(END,'Total Cost:\n')
                self.txtReceipt2.insert(END, str(TotalCost.get()))
                
            else:
                self.txtReceipt1.delete("1.0",END)
                self.txtReceipt2.delete("1.0",END)
                self.txtReceipt1.insert(END,"\nNo Input")
                

        def Taxi_Tax():
            global Item1
            if var1.get() == 1:
                self.txtTaxiTax.configure(state = NORMAL)
                Item1=float(50)
                TaxiTax.set("Rs " + str(Item1))
            elif var1.get() == 0:
                self.txtTaxiTax.configure(state=DISABLED)
                TaxiTax.set("0")
                Item1=0

        
        def Kilo():
            if var2.get() == 0:
                self.txtKm.configure(state=DISABLED)
                Km.set("0")
            elif var2.get() == 1 and varl1.get() != "" and varl2.get() != "":
                self.txtKm.configure(state=NORMAL)
                if varl1.get() == "CampusCafe":
                    switch ={"BoysHostel": 10,"GirlsHostel": 8,"AdmissionBlock":6,"CampusCafe": 0}
                    Km.set(switch[varl2.get()])
                elif varl1.get() == "BoysHostel":
                    switch ={"BoysHostel": 0,"GirlsHostel": 2,"AdmissionBlock":5,"CampusCafe": 10}
                    Km.set(switch[varl2.get()])
                elif varl1.get() == "GirlsHostel":
                    switch ={"BoysHostel": 2,"GirlsHostel": 0,"AdmissionBlock":3,"CampusCafe": 8}
                    Km.set(switch[varl2.get()])
                elif varl1.get() == "AdmissionBlock":
                    switch ={"BoysHostel": 5,"GirlsHostel": 3,"AdmissionBlock":0,"CampusCafe": 6}
                    Km.set(switch[varl2.get()])        

        
        def Lug():
            global Item4
            if (var4.get()==1):
                self.txtLuggage.configure(state = NORMAL)
                Item4=float(30)
                Luggage.set("Rs "+ str(Item4))
            elif var4.get()== 0:
                self.txtLuggage.configure(state = DISABLED)
                Luggage.set("0")
                Item4=0

        
        def selectCar():
            global Item5
            if carType.get() == 1:
                self.txtPrimeSedan.configure(state = DISABLED)
                PrimeSedan.set("0") 
                self.txtPremiumSedan.configure(state = DISABLED)
                PremiumSedan.set("0")
                self.txtEAUTO.configure(state = NORMAL)
                Item5 = float(8)
                EAUTO.set("Rs "+ str(Item5))
            elif carType.get() == 2:
                self.txtEAUTO.configure(state =DISABLED)
                EAUTO.set("0")
                self.txtPremiumSedan.configure(state = DISABLED)
                PremiumSedan.set("0")
                self.txtPrimeSedan.configure(state = NORMAL)
                Item5 = float(15)
                PrimeSedan.set("Rs "+ str(Item5))
            else:
                self.txtEAUTO.configure(state =DISABLED)
                EAUTO.set("0")
                self.txtPrimeSedan.configure(state = DISABLED)
                PrimeSedan.set("0")
                self.txtPremiumSedan.configure(state = NORMAL)
                Item5 = float(20)
                PremiumSedan.set("Rs "+ str(Item5))
                
                       
        def Total_Paid():
            if ((var1.get() == 1 and var2.get() == 1 and var3.get() == 1 or var4.get() == 1) and carType.get() != 0 and journeyType.get() != 0 and (varl1.get() != "" and varl2.get() !="")):
                if journeyType.get()==1:
                    Item2=Km.get()
                    Cost_of_fare = (Item1+(float(Item2)*Item5)+Item4)

                    Tax = "Rs " + str('%.2f'%((Cost_of_fare) *0.09))
                    ST = "Rs " + str('%.2f'%((Cost_of_fare)))
                    TT = "Rs " + str('%.2f'%(Cost_of_fare+((Cost_of_fare)*0.9)))
                elif journeyType.get()==2:
                    Item2=Km.get()
                    Cost_of_fare = (Item1+(float(Item2)*Item5)*1.5+Item4)

                    Tax = "Rs " + str('%.2f'%((Cost_of_fare) *0.09))
                    ST = "Rs " + str('%.2f'%((Cost_of_fare)))
                    TT = "Rs " + str('%.2f'%(Cost_of_fare+((Cost_of_fare)*0.9)))
                else:
                    Item2=Km.get()
                    Cost_of_fare = (Item1+(float(Item2)*Item5)*2+Item4)

                    Tax = "Rs " + str('%.2f'%((Cost_of_fare) *0.09))
                    ST = "Rs " + str('%.2f'%((Cost_of_fare)))
                    TT = "Rs " + str('%.2f'%(Cost_of_fare+((Cost_of_fare)*0.9)))

                PaidTax.set(Tax)
                SubTotal.set(ST)
                TotalCost.set(TT)
            else:
                w = ms.showwarning("Error !","Invalid Input\nPlease try again !!!")

            

   #================================================mainframe========================================================================

        MainFrame=Frame(self.root)
        MainFrame.pack(fill=BOTH,expand=True)
        
        Tops = Frame(MainFrame, bd=4,width=1350,relief=SOLID)
        Tops.pack(side=TOP,expand=True)

        self.lblTitle=Label(Tops,font=('Felix Titling',60,'bold'),text=" CAB BOOKING SYSTEM INSIDE LPU")
        self.lblTitle.config(bg= "#ff6600", fg= "black")

        self.lblTitle.grid()

    #================================================customerframedetail=============================================================
        CustomerDetailsFrame=LabelFrame(MainFrame,width=1350,height=500, relief=SOLID)
        CustomerDetailsFrame.pack(side=BOTTOM,expand=True)

        FrameDetails=Frame(CustomerDetailsFrame,width=900,height=400, relief=SOLID)
        FrameDetails.config(bg='#ff6600')
        FrameDetails.pack(side=LEFT,expand=True)

        CustomerName=LabelFrame(FrameDetails, width=150,height=250, font=('TIMES',12,'bold'),text="Customer Name", relief=SOLID)
        CustomerName.config(bg='#ff6600')
        CustomerName.grid(row=0,column=0)

        TravelFrame = LabelFrame(FrameDetails,width=300,height=250, font=('TIMES',12,'bold'),text="Booking Detail", relief=SOLID)
        TravelFrame.config(bg='#ff6600')
        TravelFrame.grid(row=1,column=0)

        Book_Frame=LabelFrame(FrameDetails,width=300,height=150,relief=SOLID)
        Book_Frame.config(bg='#ff6600')
        Book_Frame.grid(row=0,column=1)

        CostFrame = LabelFrame(FrameDetails,width=150,height=150,relief=SOLID)
        CostFrame.config(bg='#ff6600')
        CostFrame.grid(row=1,column=1)


    #===============================================recipt======================================================================
        Receipt_BottonFrame=LabelFrame(CustomerDetailsFrame, width=450,height=400,bg="#ff6600", relief=SOLID)
        Receipt_BottonFrame.pack(side=RIGHT,fill=BOTH,expand=True)

        ReceiptFrame=LabelFrame(Receipt_BottonFrame, width=350,height=300,bg="#ff6600", font=('TIMES',12,'bold'),text="Receipt", relief=SOLID)
        ReceiptFrame.grid(row=0,column=0)

        ButtonFrame=LabelFrame(Receipt_BottonFrame, width=350,height=100,bg="#ff6600", relief=SOLID)
        ButtonFrame.grid(row=1,column=0)
    #=========================================================CustomerName====================================================

        self.lblName=Label(CustomerName,font=('TIMES',14,'bold'),text="Name",bd=7,bg="#ff6600")
        self.lblName.grid(row=0,column=0,sticky=W)
        self.txtName=Entry(CustomerName,font=('TIMES',14,'bold'),textvariable=Name,bd=7,bg="gray",insertwidth=2,justify=RIGHT)
        self.txtName.grid(row=0,column=1)


        self.lblUID=Label(CustomerName,font=('TIMES',14,'bold'),text="UID",bd=7,bg="#ff6600")
        self.lblUID.grid(row=1,column=0,sticky=W)
        self.txtUID=Entry(CustomerName,font=('TIMES',14,'bold'),textvariable=UID,bd=7,bg="gray",insertwidth=2,justify=RIGHT)
        self.txtUID.grid(row=1,column=1,sticky=W)


        self.lblAddress=Label(CustomerName,font=('TIMES',14,'bold'),text="Address",bd=7,bg="#ff6600")
        self.lblAddress.grid(row=2,column=0,sticky=W)
        self.txtAddress=Entry(CustomerName,font=('TIMES',14,'bold'),textvariable=Address,bd=7,bg="gray",insertwidth=2,justify=RIGHT)
        self.txtAddress.grid(row=2,column=1)

        self.lblMobile=Label(CustomerName,font=('TIMES',14,'bold'),text="Mobile",bd=7,bg="#ff6600")
        self.lblMobile.grid(row=5,column=0,sticky=W)
        self.txtMobile=Entry(CustomerName,font=('TIMES',14,'bold'),textvariable=Mobile,bd=7,bg="gray",insertwidth=2,justify=RIGHT)
        self.txtMobile.grid(row=5,column=1)

        self.lblEmail=Label(CustomerName,font=('TIMES',14,'bold'),text="Email",bd=7,bg="#ff6600")
        self.lblEmail.grid(row=6,column=0,sticky=W)
        self.txtEmail=Entry(CustomerName,font=('TIMES',14,'bold'),textvariable=Email,bd=7,bg="gray",insertwidth=2,justify=RIGHT)
        self.txtEmail.grid(row=6,column=1)

 
    #===============================================Taxi Information==============================================================
        self.lblPickup=Label(TravelFrame,font=('TIMES',14,'bold'),text="Pickup",bd=7,bg="#ff6600")
        self.lblPickup.grid(row=0,column=0,sticky=W)

        self.cboPickup =ttk.Combobox(TravelFrame, textvariable = varl1 , state='readonly', font=('TIMES',20,'bold'),width=14)
        self.cboPickup['value']=('','CampusCafe','AdmissionBlock','GirlsHostel','BoysHostel')
        self.cboPickup.current(0)
        self.cboPickup.grid(row=0,column=1)


        self.lblDrop=Label(TravelFrame,font=('TIMES',14,'bold'),text="Drop",bd=7,bg="#ff6600")
        self.lblDrop.grid(row=1,column=0,sticky=W)

        self.cboDrop =ttk.Combobox(TravelFrame, textvariable = varl2 , state='readonly', font=('TIMES',20,'bold'), width=14)
        self.cboDrop['value']=('','BoysHostel','GirlsHostel','CampusCafe','AdmissionBlock')
        self.cboDrop.current(0)
        self.cboDrop.grid(row=1,column=1)

        self.lblPooling=Label(TravelFrame,font=('TIMES',14,'bold'),text="Pooling",bd=7,bg="#ff6600")
        self.lblPooling.grid(row=2,column=0,sticky=W)

        self.cboPooling =ttk.Combobox(TravelFrame, textvariable = varl3 , state='readonly', font=('TIMES',20,'bold'), width=14)
        self.cboPooling['value']=('','1','2','3','4')
        self.cboPooling.current(1)
        self.cboPooling.grid(row=2,column=1)

    #===============================================Taxi Information==============================================================

        self.chkTaxiTax=Checkbutton(TravelFrame,text="Taxi Tax (Base Charge) *",variable = var1, onvalue=1, offvalue=0,font=('TIMES',16,'bold'),bg="#ff6600",command=Taxi_Tax).grid(row=3, column=0, sticky=W)
        self.txtTaxiTax=Label(TravelFrame,font=('TIMES',14,'bold'),textvariable=TaxiTax,bd=6,width=18,bg="gray",state= DISABLED,justify=RIGHT,relief=GROOVE)
        self.txtTaxiTax.grid(row=3,column=1)


        self.chkKm=Checkbutton(TravelFrame,text="Distance(KMs) *",variable = var2, onvalue=1, offvalue=0,font=('TIMES',16,'bold'),bg="#ff6600",command=Kilo).grid(row=4, column=0, sticky=W)
        self.txtKm=Label(TravelFrame,font=('TIMES',14,'bold'),textvariable=Km,bd=6,width=18,bg="gray",state= DISABLED,justify=RIGHT,relief=GROOVE,highlightthickness=0)
        self.txtKm.grid(row=4,column=1)
      
        self.chkLuggage=Checkbutton(TravelFrame,text="Extra Luggage",variable = var4, onvalue=1, offvalue=0,font=('TIMES',16,'bold'),bg="#ff6600",command=Lug).grid(row=6, column=0, sticky=W)
        self.txtLuggage=Label(TravelFrame,font=('TIMES',14,'bold'),textvariable=Luggage,bd=6,width=18,bg="gray",state= DISABLED,justify=RIGHT,relief=GROOVE)
        self.txtLuggage.grid(row=6,column=1)
    
    #=================================payment information ===========================================================================
         
        self.lblPaidTax=Label(CostFrame,font=('TIMES',14,'bold'),text="Paid Tax\t\t",bd=7,bg="#ff6600")
        self.lblPaidTax.grid(row=0,column=2,sticky=W)
        self.txtPaidTax = Label(CostFrame,font=('TIMES',14,'bold'),textvariable=PaidTax,bd=7, width=26, justify=RIGHT,bg="gray",relief=SUNKEN)
        self.txtPaidTax.grid(row=0,column=3)
            

        
        self.lblSubTotal=Label(CostFrame,font=('TIMES',14,'bold'),text="Sub Total",bd=7,bg="#ff6600")
        self.lblSubTotal.grid(row=1,column=2,sticky=W)
        self.txtSubTotal = Label(CostFrame,font=('TIMES',14,'bold'),textvariable=SubTotal,bd=7, width=26, justify=RIGHT,bg="gray",relief=SUNKEN)
        self.txtSubTotal.grid(row=1,column=3)



        self.lblTotalCost=Label(CostFrame,font=('TIMES',14,'bold'),text="Total Cost",bd=7,bg="#ff6600")
        self.lblTotalCost.grid(row=2,column=2,sticky=W)
        self.txtTotalCost = Label(CostFrame,font=('TIMES',14,'bold'),textvariable=TotalCost,bd=7, width=26, justify=RIGHT,bg="gray",relief=SUNKEN)
        self.txtTotalCost.grid(row=2,column=3)

    #==========================================================taxiselect=======================================================================

        self.chkEAUTO=Radiobutton(Book_Frame,text="EAUTO",value=1,variable = carType,font=('TIMES',14,'bold'),bg="#ff6600",command=selectCar).grid(row=0, column=0, sticky=W)
        self.txtEAUTO = Label(Book_Frame,font=('TIMES',14,'bold'),width =7,textvariable=EAUTO,bd=5, state= DISABLED, justify=RIGHT,bg="gray",relief=SUNKEN)
        self.txtEAUTO.grid(row=0,column=1)
        

        self.chkPrimeSedand=Radiobutton(Book_Frame,text="PrimeSedan",value=2,variable = carType,font=('TIMES',14,'bold'),bg="#ff6600",command=selectCar).grid(row=1, column=0, sticky=W)
        self.txtPrimeSedan= Label(Book_Frame,font=('TIMES',14,'bold'),width =7,textvariable=PrimeSedan,bd=5, state= DISABLED, justify=RIGHT,bg="gray",relief=SUNKEN)
        self.txtPrimeSedan.grid(row=1,column=1)
             
       
        self.chkPremiumSedan = Radiobutton(Book_Frame,text="PremiumSedan",value=3,variable = carType,font=('TIMES',14,'bold'),bg="#ff6600",command=selectCar).grid(row=2, column=0)
        self.txtPremiumSedan = Label(Book_Frame,font=('TIMES',14,'bold'),width =7,textvariable=PremiumSedan,bd=5, state= DISABLED, justify=RIGHT,bg="gray",relief=SUNKEN)
        self.txtPremiumSedan.grid(row=2,column=1)

        self.chkSingle =Radiobutton(Book_Frame,text="Single",value=1,variable = journeyType,font=('TIMES',14,'bold'),bg="#ff6600").grid(row=0, column=2, sticky=W)
        self.chkReturn =Radiobutton(Book_Frame,text="Return",value=2,variable = journeyType,font=('TIMES',14,'bold'),bg="#ff6600").grid(row=1, column=2, sticky=W)
        self.chkSpecialsNeeds =Radiobutton(Book_Frame,text="SpecialNeeds",value=3,variable = journeyType,font=('TIMES',14,'bold'),bg="#ff6600").grid(row=2, column=2, sticky=W)
    
    
    #=======================================Reciept====================================================================================

        self.txtReceipt1 = Text(ReceiptFrame,width = 22, height = 21,font=('TIMES',10,'bold'),bg="#ff6600",borderwidth=0)
        self.txtReceipt1.grid(row=0,column=0,columnspan=2)
        self.txtReceipt2 = Text(ReceiptFrame,width = 22, height = 21,font=('TIMES',10,'bold'),bg="#ff6600",borderwidth=0)
        self.txtReceipt2.grid(row=0,column=2,columnspan=2)


    #======================================Button========================================================================================
        
        self.btnTotal = Button(ButtonFrame,padx=18,bd=7,font=('TIMES',11,'bold'),width = 2,text='Total',bg="#ff6600",command=Total_Paid).grid(row=0,column=0)
        self.btnReceipt = Button(ButtonFrame,padx=18,bd=7,font=('TIMES',11,'bold'),width = 2,text='Receipt',bg="#ff6600",command=Receiptt).grid(row=0,column=1)
        self.btnReset = Button(ButtonFrame,padx=18,bd=7,font=('TIMES',11,'bold'),width = 2,text='Reset',bg="#ff6600",command=Reset).grid(row=0,column=2)
        self.btnExit = Button(ButtonFrame,padx=18,bd=7,font=('TIMES',11,'bold'),width = 2,text='Exit',bg="#ff6600", command=iExit).grid(row=0,column=3)
        
    #====================================================================================================================================

        
if __name__=='__main__':
    root = Tk()

    #=========================================== Getting Screen Width ==================================================================
    w = root.winfo_screenwidth()
    h = root.winfo_screenheight()
    geometry="%dx%d+%d+%d"%(w,h,0,0)
    
    root.geometry("500x300+320+200")
    root.title('Login Form')
    application = user(root)
    root.mainloop()
    
